﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPIVendasTurmaB.Controllers
{
    public class ClienteController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
