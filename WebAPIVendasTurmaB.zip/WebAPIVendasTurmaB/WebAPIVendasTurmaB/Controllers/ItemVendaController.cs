﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPIVendasTurmaB.Controllers
{
    public class ItemVendaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
