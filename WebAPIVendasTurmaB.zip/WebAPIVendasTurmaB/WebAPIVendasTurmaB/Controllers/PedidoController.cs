﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPIVendasTurmaB.Controllers
{
    public class PedidoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
