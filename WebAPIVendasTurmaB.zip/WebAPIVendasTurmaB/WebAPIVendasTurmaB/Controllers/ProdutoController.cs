﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPIVendasTurmaB.Controllers
{
    public class ProdutoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
